//
//  Forcast.swift
//  DemoWeather
//
//  Created by Nirav Patel on 09/05/19.
//  Copyright © 2019 Nirav Patel. All rights reserved.
//

import Foundation
import CoreData
import UIKit

class ForcastModel {
    
    static var shareInstance = ForcastModel()
    
    let context = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext
    
    func save(object:[String:Any]){
        
        let forcast = NSEntityDescription.insertNewObject(forEntityName: "Forcast", into: context!) as! Forcast
        
        forcast.currentTemp = object["currentTemp"] as? String
        forcast.date = object["date"] as? String
        forcast.humidity = object["humidity"] as? String
        forcast.maxTemp = object["maxTemp"] as? String
        forcast.minTemp = object["minTemp"] as? String
       
    
        do{
            try context?.save()
            print("Data Saved :) ")
        }catch{
            print("Data not save!!!")
        }
        
    }
    
    func getForcastData() -> [Forcast]{
        var forcast = [Forcast]()
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Forcast")
        do{
            forcast = try context?.fetch(fetchRequest) as! [Forcast]

            print("\(forcast)")
        }catch{
            print("Could not found Data!!!")
        }
        return forcast
    }
    
    func deleteForcastData(index:Int) -> [Forcast]{
        var forcast = getForcastData()
        context?.delete(forcast[index])
        forcast.remove(at: index)
        do{
            try context?.save()
        }catch{
            print("cannot dalete Data")
        }
        return forcast
    }
    
    func update(forcastDict:[String:Any]){
        
        var forcasts = [Forcast]()
        
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Forcast")
        fetchRequest.predicate = NSPredicate(format: "SELF.date like %@", forcastDict["date"] as! String)
        do{
            forcasts = try context?.fetch(fetchRequest) as! [Forcast]
            
            if forcasts.count > 0 {
                
                let forcast = forcasts[0]
                
                forcast.date = forcastDict["date"] as? String
                forcast.currentTemp = forcastDict["currentTemp"] as? String
                forcast.minTemp = forcastDict["minTemp"] as? String
                forcast.maxTemp = forcastDict["maxTemp"] as? String
                forcast.humidity = forcastDict["humidity"] as? String
               
                
            }
            print("\(forcasts)")
        }catch{
            print("Could not found Data!!!")
        }

        
        do{
            try context?.save()
            print("Data Updated... :) ")
        }catch{
            print("Data not Updated!!!")
        }
        
    }
}
