//
//  Forcast+CoreDataClass.swift
//  DemoWeather
//
//  Created by Nirav Patel on 09/05/19.
//  Copyright © 2019 Nirav Patel. All rights reserved.
//
//

import Foundation
import CoreData


public class Forcast: NSManagedObject {

}
