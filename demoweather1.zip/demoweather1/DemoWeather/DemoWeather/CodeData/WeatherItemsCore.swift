//
//  WeatherItemsCore.swift
//  DemoWeather
//
//  Created by Ravi Chokshi on 09/05/19.
//  Copyright © 2019 Nirav Patel. All rights reserved.
//

import Foundation

class WeatherItemsCore: Codable{
    
    
    
    var date: String
    var currentTemp: String
    var humidity: String
    var maxTemp : String
    var minTemp : String
    
    
    init(date: String, currentTemp: String, humidity: String,maxTemp : String ,minTemp : String) {
        self.date = date
        self.currentTemp = currentTemp
        self.humidity = humidity
        self.maxTemp = maxTemp
        self.minTemp = minTemp
    }
    
    
}
