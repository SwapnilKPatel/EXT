//
//  Forcast+CoreDataProperties.swift
//  DemoWeather
//
//  Created by Nirav Patel on 09/05/19.
//  Copyright © 2019 Nirav Patel. All rights reserved.
//
//

import Foundation
import CoreData


extension Forcast {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Forcast> {
        return NSFetchRequest<Forcast>(entityName: "Forcast")
    }

    @NSManaged public var currentTemp: String?
    @NSManaged public var date: String?
    @NSManaged public var humidity: String?
    @NSManaged public var maxTemp: String?
    @NSManaged public var minTemp: String?
   

}
