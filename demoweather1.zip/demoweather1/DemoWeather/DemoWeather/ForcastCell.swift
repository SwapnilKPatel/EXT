//
//  ForcastCell.swift
//  DemoWeather
//
//  Created by Ravi Chokshi on 09/05/19.
//  Copyright © 2019 Nirav Patel. All rights reserved.
//

import UIKit

class ForcastCell: UITableViewCell {

    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var currentTempLabel: UILabel!
    @IBOutlet weak var minTempLabel: UILabel!
    @IBOutlet weak var maxTempLabel: UILabel!
    @IBOutlet weak var humidityLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    func bindData(data : Forcast)
    {
        self.selectionStyle = .none
       
        self.currentTempLabel.text = data.currentTemp
        self.minTempLabel.text = data.minTemp
        self.maxTempLabel.text = data.maxTemp
        self.humidityLabel.text = data.humidity
        
        guard let temp = data.currentTemp  else {
             self.dateLabel.text = "NA"
            return
        }
        guard let max_temp = data.maxTemp  else {
            self.maxTempLabel.text = "NA";
            return
        }
        guard let min_temp = data.minTemp else {
           self.minTempLabel.text = "NA";
            return
        }
        let defaults = UserDefaults.standard
        
        guard let userdefault = defaults.string(forKey: "type") else {
            
            self.dateLabel.text = data.date
            self.currentTempLabel.text = "Current Temp : " + String(Int(round((Double(temp))!))) + "\u{00B0}C"
            self.maxTempLabel.text = "Max Temp : " + String(Int(round((Double(max_temp))!))) + "\u{00B0}C"
            self.minTempLabel.text = "Min Temp : " + String(Int(round((Double(min_temp))!))) + "\u{00B0}C"
            self.humidityLabel.text = "humidity: " + data.humidity!
            // self.temp_type.text = "\u{00B0}C"
            return
        }
        
        if userdefault == CELCIUS{
            let ctemp = TempConversion.sharedInstance.kelvintocelcius(K: (Double(temp))!)
            
                       self.dateLabel.text = data.date
                        self.currentTempLabel.text = "Current Temp : " + String(Int(round(ctemp))) + "\u{00B0}C"
                        self.maxTempLabel.text = "Max Temp : " + String(Int(round(ctemp))) + "\u{00B0}C"
                        self.minTempLabel.text = "Min Temp : " + String(Int(round(ctemp))) + "\u{00B0}C"
                       self.humidityLabel.text = "humidity: " + data.humidity!
                      //  self.temp_type.text = "\u{00B0}C"
        }
      
        
        
        
        
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
