//
//  MainVCAndTableView.swift
//  DemoWeather
//
//  Created by Ravi Chokshi on 09/05/19.
//  Copyright © 2019 Nirav Patel. All rights reserved.
//

import Foundation
import UIKit
extension MainVC :UITableViewDelegate,UITableViewDataSource {
    
    func tableViewSetup()  {
        tableView = UITableView(frame: CGRect(x: 0, y: 0, width: SCREEN_WIDTH, height: SCREEN_HEIGHT), style: .plain)
        tableView.delegate = self
        tableView.dataSource = self
        self.view.addSubview(tableView)
        tableView.separatorStyle = .none
        tableView.register(UINib(nibName: "ForcastCell", bundle: nil), forCellReuseIdentifier: "ForcastCell")
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 154
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return forcastData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
       
           let cell = tableView.dequeueReusableCell(withIdentifier: "ForcastCell", for: indexPath) as! ForcastCell
        let data  = forcastData[indexPath.row] 
        cell.bindData(data: data)
        //var data : ProjectDataModel!
        
        //  cell.textLabel?.text = data.name
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        
    }
    
}
