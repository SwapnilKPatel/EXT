//
//  MainVC.swift
//  DemoWeather
//
//  Created by Ravi Chokshi on 09/05/19.
//  Copyright © 2019 Nirav Patel. All rights reserved.
//

import UIKit
import CoreLocation
class MainVC: UIViewController {
    
    let manager = APIManager.sharedInstance
    var weatherItemsCore : WeatherItemsCore!
    var weatherItems = [WeatherItem]()
    var forcastData = [Forcast]()
    var tableView : UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
       
        tableViewSetup()
        Timer.scheduledTimer(timeInterval: 0.5, target: self, selector: #selector(callweather), userInfo: nil, repeats: false)
    
        
        
    }
   
    
  
    @objc func callweather(){
        let lat  : String = "22.3072"
        let long : String = "73.1812"
        
        if appDel!.isNetworkAvailable() == true{
           // // online data fetch
        APIManager.sharedInstance.loadWeatherData(url: "http://api.openweathermap.org/data/2.5/weather?lat=\(lat)&lon=\(long)&appid=6b2dd165a5eec1605cacbfaa45d4b218",completionHandler: self.APICompletionHandler(response:) )
        }
        else{
            // offline data fetch
            forcastData = ForcastModel.shareInstance.getForcastData()
            self.tableView.reloadData()
            
        }
    }
    
    func APICompletionHandler(response: [WeatherItem]) {
        
        
        
        weatherItems = response
       
        var weatherData = [String:Any]()
        weatherData["date"] = "\(Date().description)"
        weatherData["currentTemp"] = "\(weatherItems[0].temp ?? 0.00 )"
        weatherData["minTemp"] = "\(weatherItems[0].temp_min ?? 0.00)"
        weatherData["maxTemp"] = "\(weatherItems[0].temp_max ?? 0.00)"
        weatherData["humidity"] = "\(weatherItems[0].humadity ?? 0.00)"
        ForcastModel.shareInstance.save(object: weatherData)
        forcastData = ForcastModel.shareInstance.getForcastData()
        tableView.reloadData()
        
        
    }
    
    
    
    
    
   
}
