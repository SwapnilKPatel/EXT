//
//  ViewController.swift
//  DemoWeather
//
//  Created by Nirav Patel on 09/05/19.
//  Copyright © 2019 Nirav Patel. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

