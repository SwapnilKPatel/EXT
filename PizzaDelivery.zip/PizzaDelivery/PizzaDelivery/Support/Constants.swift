//
//  Constants.swift
//  PizzaDelivery
//
//  Created by Ravi Chokshi on 26/02/19.
//  Copyright © 2019 Ravi Chokshi. All rights reserved.
//
typealias JSONDictionary = [String:AnyObject]

typealias JSONArray      = Array<AnyObject>

struct Constants {
  
    let APP_PRIMARY_COOLOR = "kelvin"
    let FORENHITE = "fahrenheit"
}
