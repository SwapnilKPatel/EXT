//
//  MainVC.swift
//  PizzaDelivery
//
//  Created by Ravi Chokshi on 26/02/19.
//  Copyright © 2019 Ravi Chokshi. All rights reserved.
//

import UIKit

class MainVC: UIViewController {
    
    @IBOutlet weak var welcomeLabel: UILabel!
    
    @IBOutlet weak var oneFlavourPizzaButton: UIButton!
    
    @IBOutlet weak var twoFlavourPizzaButton: UIButton!
    
    @IBOutlet weak var detailLabel: UILabel!
    
    let appDel = (UIApplication.shared.delegate as? AppDelegate)
    override func viewDidLoad() {
        super.viewDidLoad()

       fetch()
      
    }
    
    func fetch()  {
//        if appDel!.isNetworkAvailable() != true{
//
//            return
//        }
        APIManager.sharedInstance.fectchPizzaFlavors(url: "https://static.mozio.com/mobile/tests/pizzas.json",completionHandler: self.APICompletionHandler(response:) )
    }
    
    func APICompletionHandler(response: [PizzaFlavors]) {
        
        print(response)

        
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
