//
//  PizzaFlavors.swift
//  PizzaDelivery
//
//  Created by Ravi Chokshi on 26/02/19.
//  Copyright © 2019 Ravi Chokshi. All rights reserved.
//

import Foundation
class PizzaFlavors {
    /*
     [
     {
     "name": "Mozzarella",
     "price": 10
     }, {
     "name": "Pepperoni",
     "price": 12
     }, {
     "name": "Vegetarian",
     "price": 9.5
     }, {
     "name": "Super cheese",
     "price": 11
     }
     ]
 */
    
    private var _name        : String?
    private var _price          : String?

    
    
    public init(data : JSONDictionary){
        if let name    = data["name"] as? String{
            self._name  = name
        }
        
        if  let price    = data["price"] as? String{
            self._price  = price
            
        }
        
      
    }
    
    var name : String? {
        return _name
    }
    
    var price : String?{
        return _price
    }
    
  
}
