//
//  APIManager.swift
//  PizzaDelivery
//
//  Created by Ravi Chokshi on 26/02/19.
//  Copyright © 2019 Ravi Chokshi. All rights reserved.
//

import Foundation


class APIManager{
    public static let  sharedInstance = APIManager()
 
    
    func fectchPizzaFlavors(url : String,completionHandler: (([PizzaFlavors]) -> Void)? = nil){
        URLSession.shared.dataTask(with: URL(string : url)!) { (data, response, error) in
            print("LOAD")
            if (error != nil){
                print(error?.localizedDescription ?? "NA")
            }else{
                do{
                    if let json = try JSONSerialization.jsonObject(with: data!, options: .allowFragments) as? JSONDictionary{
                        print(json)
                        
                        let pizzaFlavors = [PizzaFlavors]()
                        
                        let a = PizzaFlavors(data: json)
                        print(a)
                        
                        
                        
                        DispatchQueue.main.async {
                            // self.delegate?.didWeatherAvailable(weatherItems: weatherItems)
                            
                            if completionHandler != nil {
                                
                                completionHandler!(pizzaFlavors)
                                return
                            }
                            
                        }
                    }
                    
                    
                    
                    
                }catch{
                    print(error.localizedDescription)
                }
            }
            }.resume()
        
    }
    
}
